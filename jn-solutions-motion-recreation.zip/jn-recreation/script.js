const progress=document.querySelector('.progress');
const glow=document.querySelector('.cursor-glow');
window.addEventListener('scroll',()=>{const max=document.documentElement.scrollHeight-innerHeight;progress.style.width=(max?scrollY/max*100:0)+'%';},{passive:true});
window.addEventListener('pointermove',e=>{glow.style.left=e.clientX+'px';glow.style.top=e.clientY+'px';},{passive:true});
const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}}),{threshold:.12});
document.querySelectorAll('.reveal').forEach((el,i)=>{el.style.transitionDelay=(Math.min(i%4,3)*70)+'ms';observer.observe(el)});
document.querySelector('#year').textContent=new Date().getFullYear();
// Lightweight menu behavior for small screens
const menu=document.querySelector('.menu');menu.addEventListener('click',()=>{let nav=document.querySelector('.nav nav');const open=nav.style.display==='flex';nav.style.display=open?'none':'flex';nav.style.position='absolute';nav.style.top='72px';nav.style.left='0';nav.style.right='0';nav.style.padding='25px 6vw';nav.style.background='#080a0b';nav.style.flexDirection='column';nav.style.borderBottom='1px solid #252b2a';});
