# JN Solutions — motion-led website recreation

A responsive static website prototype for JN Solutions. Built with HTML, CSS, and vanilla JavaScript; no framework or build step required.

## Preview locally
Open `index.html` in a browser. Google Fonts are loaded online; system fallback fonts work offline.

## Deploy to Vercel
1. Upload this folder to a GitHub repository (or import it into Vercel).
2. In Vercel choose **Other** / static site, with no build command.
3. Set the output directory to the project root (`.`).

## Before publishing
- Replace `hello@jnsolutions.in` with your real business inbox if different.
- Add real client outcomes, testimonials, founder photos, and a privacy policy.
- Verify all service names, claims, and contact links.
- This is a front-end concept; it does not include backend forms, CRM, analytics, or booking integrations.
